package com.example.demo;

public class AppConstants {
	
	public static final String TOPIC_NAME = "test";
	public static final String GROUP_ID = "group_id";

}
