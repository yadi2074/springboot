package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
//import com.howtodoinjava.kafka.demo.service.KafKaProducerService;
import com.example.demo.service.KafkaProduceerService;


@RestController
@RequestMapping(value = "/kafka")
public class KafkaProducerController {
	
	private KafkaProduceerService producerService;

	@Autowired
	public KafkaProducerController(KafkaProduceerService producerService)
	{
		this.producerService = producerService;
	}

	@PostMapping(value = "/publish")
	public void sendMessageToKafkaTopic(@RequestParam("message") String message)
	{
		this.producerService.sendMessage(message);
	}

}
